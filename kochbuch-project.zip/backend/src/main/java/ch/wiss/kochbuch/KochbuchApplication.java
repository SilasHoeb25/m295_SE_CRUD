package ch.wiss.kochbuch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KochbuchApplication {

	public static void main(String[] args) {
		SpringApplication.run(KochbuchApplication.class, args);
	}

}
